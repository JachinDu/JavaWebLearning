create
    definer = root@localhost procedure pro_findById(IN eid int)
begin
		select * from employee where id=eid;
end;

