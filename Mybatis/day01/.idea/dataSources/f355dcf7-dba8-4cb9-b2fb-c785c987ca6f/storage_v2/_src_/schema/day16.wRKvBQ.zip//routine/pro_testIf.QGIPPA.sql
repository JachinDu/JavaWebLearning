create
    definer = root@localhost procedure pro_testIf(IN num int, OUT str varchar(20))
begin
		if num=1 then
				set str='星期一';
		elseif num=2 then
				set str='二';
		elseif num=3 then
				set str='三';
		else
				set str='输错了';
		end if;
end;

