create
    definer = root@localhost procedure pro_findById2(IN sid int, OUT sname varchar(20))
begin
		select name into sname from student where id=sid;
end;

